# All Stock Fund — Installation Guide

## How to install on your phone in 5 minutes

### STEP 1 — Create a free Vercel account
1. Go to **vercel.com** on your computer
2. Click "Sign Up" → sign up with Google or GitHub (free)

### STEP 2 — Deploy the app
1. Go to **vercel.com/new**
2. Click **"Import Git Repository"** → or just drag the project folder
3. Actually the easiest: use Vercel CLI or GitHub

### EASIEST METHOD — GitHub + Vercel
1. Go to **github.com** → create free account
2. Click "New repository" → name it "allstockfund" → Public → Create
3. Upload all files from this folder (drag & drop in GitHub)
4. Go to **vercel.com** → "Add New Project" → import your GitHub repo
5. Click Deploy → wait 1 minute → you get a URL like allstockfund.vercel.app

### STEP 3 — Install on iPhone
1. Open Safari on your iPhone
2. Go to your Vercel URL (e.g. allstockfund.vercel.app)
3. Tap the **Share button** (box with arrow) at the bottom
4. Tap **"Add to Home Screen"**
5. Tap **"Add"** → done! It's on your home screen like a real app

### STEP 4 — Install on Android
1. Open Chrome on your Android phone
2. Go to your Vercel URL
3. Tap the **3 dots menu** (top right)
4. Tap **"Add to Home screen"** or **"Install app"**
5. Tap **"Add"** → done!

### UPDATING DATA (no code needed)
- Open the app → go to **Admin tab** (⚙ icon)
- **Upload CSV**: Export your Excel as CSV → upload in Admin panel
- **Edit stats**: Type new numbers directly → Save
- All data saves automatically to your phone memory
